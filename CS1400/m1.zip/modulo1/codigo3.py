""" Piensa en Python: Capitulo 1 La programacion como forma de pensar"""
#TODO 1: #Declara un variable con un número entero muy grande, llamado numero_grande.


#Convierte ese número a cadena usando str().
#numero_texto = str(numero_grande)

#TODO 2: Usa len() para contar cuántos dígitos tiene el variable numero_texto, e imprimirlo a la terminal.


#TODO 3: Declara una frase corta de string como texto usando "" o '', usa el variable frase.


#Usa len() para contar cuántos caracteres tiene (incluyendo espacios) e imprimirlo a la terminal.
#print("Caracteres en frase:", len(frase))
