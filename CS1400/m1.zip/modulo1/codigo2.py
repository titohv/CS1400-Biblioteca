""" Piensa en Python: Capitulo 1 La programacion como forma de pensar"""
#TODO 1: Delcara un número decimal largo (mas de 2 numeros despues del .) llamado precio


# Usa round() para redondear el variable precio a el entero más cercano 
round(precio)

# Prueba que lo lograste imprimiendo el variable precio
print(precio)

# TODO 2: Usa la funcion round() para redondear a el entero mas cercano PERO ahora con solo dos cifras decimales, e imprimirlo.
# Por ejemplo si tu numero del TODO 1 fue 23.2350983. La salida despues del TODO 2 debe ser: 23.23
# PISTA: Hay mas de una manera para lograr el objetivo. 



#Delcara un número decimal largo llamado saldo
saldo = -150.6546152789543357

#Imprimir saldo de la instruccion anterior
print(saldo)

# TODO 3: Usa abs() para imprimir el valor absoluto del variable saldo.
